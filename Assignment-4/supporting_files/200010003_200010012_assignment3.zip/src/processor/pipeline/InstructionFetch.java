package processor.pipeline;

import processor.Processor;

public class InstructionFetch {
	
	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performIF()
	{

		if(IF_EnableLatch.isIF_enable())
		{
			if(EX_IF_Latch.getIsBranch_enable()){
				int newPC = EX_IF_Latch.getPC();
				containingProcessor.getRegisterFile().setProgramCounter(newPC);
				EX_IF_Latch.setIsBranch_enable(false);
			}
			int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
			int newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
			IF_OF_Latch.setInstruction(newInstruction);
			containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
			// System.out.println(" inside IF 1");
			// String opcode = Integer.toBinaryString(newInstruction).substring(0,5);
			// System.out.println(opcode);
			IF_EnableLatch.setIF_enable(false);
			IF_OF_Latch.setOF_enable(true);
		}
		// else if(EX_IF_Latch.getIsBranch_enable()){
		// 	int newPC = EX_IF_Latch.getPC();
		// 	// System.out.println("\n"+newPC);
		// 	System.out.println(" Inside IF 2");
		// 	int newInst = containingProcessor.getMainMemory().getWord(newPC);
		// 	String opcode = Integer.toBinaryString(newInst).substring(0,5);
		// 	System.out.println(opcode);
		// 	IF_OF_Latch.setInstruction(newInst);
		// 	containingProcessor.getRegisterFile().setProgramCounter(newPC);
		// 	EX_IF_Latch.setIsBranch_enable(false);
		// 	IF_OF_Latch.setOF_enable(true);
		// }
	}

}
